/* RED5 Open Source Flash Server - http://code.google.com/p/red5/
 *
 * Copyright 2006-2013 by respective authors (see below). All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License. */

package org.red5.io.flv.impl;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.ClosedChannelException;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

import org.apache.mina.core.buffer.IoBuffer;
import org.red5.codec.AudioCodec;
import org.red5.io.IStreamableFile;
import org.red5.io.ITag;
import org.red5.io.ITagWriter;
import org.red5.io.amf.Input;
import org.red5.io.amf.Output;
import org.red5.io.flv.FLVHeader;
import org.red5.io.flv.IFLV;
import org.red5.io.utils.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A Writer is used to write the contents of a FLV file
 *
 * @author The Red5 Project
 * @author Dominick Accattato (daccattato@gmail.com)
 * @author Luke Hubbard, Codegent Ltd (luke@codegent.com)
 * @author Tiago Jacobs (tiago@imdt.com.br)
 * @author Paul Gregoire (mondain@gmail.com)
 */
public class FLVWriter implements ITagWriter
{
    private static Logger LOGGER = LoggerFactory.getLogger(FLVWriter.class);

    /**
     * Length of the flv header in bytes
     */
    public final static int HEADER_LENGTH = 9;

    /**
     * Length of the flv tag in bytes
     */
    public final static int TAG_HEADER_LENGTH = 11;

    /**
     * Position of the meta data tag in our file.
     */
    public final static int META_POSITION = 13;

    /**
     * For now all recorded streams carry a stream id of 0.
     */
    public final static byte[] DEFAULT_STREAM_ID = new byte[] { (byte)(0 & 0xff), (byte)(0 & 0xff), (byte)(0 & 0xff) };

    /**
     * FLV object
     */
    private IFLV myFLV;

    /**
     * Number of bytes written
     */
    private volatile long myBytesWritten;

    /**
     * Position in file
     */
    private int myPositionOffset;

    /**
     * Position in file
     */
    private int myTimeOffset;

    /**
     * Id of the video codec used.
     */
    private volatile int myVideoCodecId = -1;

    /**
     * Id of the audio codec used.
     */
    private volatile int myAudioCodecId = -1;

    /**
     * Sampling rate
     */
    private volatile int mySoundRate;

    /**
     * Size of each audio sample
     */
    private volatile int mySoundSize;

    /**
     * Mono (0) or stereo (1) sound
     */
    private volatile boolean mySoundType;

    /**
     * Are we appending to an existing file?
     */
    private boolean myAppend;

    /**
     * Duration of the file.
     */
    private int myDuration;

    /**
     * Size of video data
     */
    private int myVideoDataSize = 0;

    /**
     * Size of audio data
     */
    private int myAudioDataSize = 0;

    /**
     * Flv file.
     */
    private RandomAccessFile myFile;

    /**
     * File to which stream data is stored without an flv header or metadata.
     */
    private RandomAccessFile myDataFile;

    private final Map<Long, ITag> myMetaTags = new HashMap<Long, ITag>();

    // path to the original file passed to the writer
    private final String myFilePath;

    private final Semaphore myLock = new Semaphore(1, true);

    /**
     * Creates writer implementation with given file and last tag
     *
     * FLV.java uses this constructor so we have access to the file object
     *
     * @param file File output stream
     * @param append true if append to existing file
     */
    public FLVWriter(File file, boolean append)
    {
        myFilePath = file.getAbsolutePath();
        LOGGER.debug("Writing to: {}", myFilePath);
        try
        {
            myAppend = append;
            if (append)
            {
                // if we are appending get the last tags timestamp to use as
                // offset
                myTimeOffset = FLVReader.getDuration(file);
                // set duration to last timestamp value
                myDuration = myTimeOffset;
                LOGGER.debug("Duration: {}", myTimeOffset);
                // grab the file we will append to
                myDataFile = new RandomAccessFile(file, "rw");
                if (!file.exists() || !file.canRead() || !file.canWrite())
                {
                    LOGGER.warn("File does not exist or cannot be accessed");
                }
                else
                {
                    LOGGER.trace("File size: {} last modified: {}", file.length(), file.lastModified());
                    // update the bytes written so we write to the correct
                    // starting position
                    myBytesWritten = file.length();
                }
                // if duration is 0 then we probably have larger issues with
                // this file
                if (myDuration == 0)
                {
                    // seek to where metadata would normally start
                    myDataFile.seek(META_POSITION);
                }
            }
            else
            {
                // temporary data file for storage of stream data
                File dat = new File(myFilePath + ".ser");
                if (dat.exists())
                {
                    dat.delete();
                    dat.createNewFile();
                }
                myDataFile = new RandomAccessFile(dat, "rw");
            }
        }
        catch (Exception e)
        {
            LOGGER.error("Failed to create FLV writer", e);
        }
    }

    /**
     * Writes the header bytes
     *
     * @throws IOException Any I/O exception
     */
    public void writeHeader() throws IOException
    {
        FLVHeader flvHeader = new FLVHeader();
        flvHeader.setFlagAudio(myAudioCodecId != -1 ? true : false);
        flvHeader.setFlagVideo(myVideoCodecId != -1 ? true : false);
        // create a buffer
        ByteBuffer header = ByteBuffer.allocate(HEADER_LENGTH + 4); // FLVHeader
                                                                    // (9 bytes)
                                                                    // +
                                                                    // PreviousTagSize0
                                                                    // (4 bytes)
        flvHeader.write(header);
        // the final version of the file will go here
        myFile = new RandomAccessFile(myFilePath, "rw");
        // write header to output channel
        myFile.setLength(HEADER_LENGTH + 4);
        if (header.hasArray())
        {
            LOGGER.debug("Header bytebuffer has a backing array");
            myFile.write(header.array());
        }
        else
        {
            LOGGER.debug("Header bytebuffer does not have a backing array");
            byte[] tmp = new byte[HEADER_LENGTH + 4];
            header.get(tmp);
            myFile.write(tmp);
        }
        myBytesWritten = myFile.length();
        assert HEADER_LENGTH + 4 - myBytesWritten == 0;
        LOGGER.debug("Header size: {} bytes written: {}", HEADER_LENGTH + 4, myBytesWritten);
        header.clear();
        header = null;
    }

    @Override
    public boolean writeTag(ITag tag) throws IOException
    {
        try
        {
            myLock.acquire();
            /* Tag header = 11 bytes |-|---|----|---| 0 = type 1-3 = data size
             * 4-7 = timestamp 8-10 = stream id (always 0) Tag data = variable
             * bytes Previous tag = 4 bytes (tag header size + tag data size) */
            LOGGER.trace("writeTag: {}", tag);
            long prevBytesWritten = myBytesWritten;
            LOGGER.trace("Previous bytes written: {}", prevBytesWritten);
            // skip tags with no data
            int bodySize = tag.getBodySize();
            LOGGER.debug("Tag body size: {}", bodySize);
            // ensure that the channel is still open
            if (myDataFile != null)
            {
                LOGGER.debug("Current file position: {}", myDataFile.getChannel().position());
                // get the data type
                byte dataType = tag.getDataType();
                // if we're writing non-meta tags do seeking and tag size update
                if (dataType != ITag.TYPE_METADATA)
                {
                    // get the current file offset
                    long fileOffset = myDataFile.getFilePointer();
                    LOGGER.debug("Current file offset: {} expected offset: {}", fileOffset, prevBytesWritten);
                    if (fileOffset < prevBytesWritten)
                    {
                        LOGGER.debug("Seeking to expected offset");
                        // it's necessary to seek to the length of the file
                        // so that we can append new tags
                        myDataFile.seek(prevBytesWritten);
                        LOGGER.debug("New file position: {}", myDataFile.getChannel().position());
                    }
                }
                else
                {
                    tag.getBody().mark();
                    // get input data
                    Input metadata = new Input(tag.getBody());
                    // initialize type so that readString knows what to do
                    metadata.readDataType();
                    String metaType = metadata.readString(String.class);
                    LOGGER.debug("Metadata tag type: {}", metaType);
                    tag.getBody().reset();
                    if (!"onCuePoint".equals(metaType))
                    {
                        // store any incoming onMetaData tags until we close the
                        // file, allow onCuePoint tags to continue
                        myMetaTags.put(System.currentTimeMillis(), tag);
                        return true;
                    }
                }
                // set a var holding the entire tag size including the previous
                // tag length
                int totalTagSize = TAG_HEADER_LENGTH + bodySize + 4;
                // resize
                myDataFile.setLength(myDataFile.length() + totalTagSize);
                // create a buffer for this tag
                ByteBuffer tagBuffer = ByteBuffer.allocate(totalTagSize);
                // get the timestamp
                int timestamp = tag.getTimestamp() + myTimeOffset;
                // allow for empty tag bodies
                byte[] bodyBuf = null;
                if (bodySize > 0)
                {
                    // create an array big enough
                    bodyBuf = new byte[bodySize];
                    // put the bytes into the array
                    tag.getBody().get(bodyBuf);
                    // get the audio or video codec identifier
                    if (dataType == ITag.TYPE_AUDIO)
                    {
                        myAudioDataSize += bodySize;
                        if (myAudioCodecId == -1)
                        {
                            int id = bodyBuf[0] & 0xff; // must be unsigned
                            myAudioCodecId = (id & ITag.MASK_SOUND_FORMAT) >> 4;
                            LOGGER.debug("Audio codec id: {}", myAudioCodecId);
                            // if aac use defaults
                            if (myAudioCodecId == AudioCodec.AAC.getId())
                            {
                                LOGGER.trace("AAC audio type");
                                // Flash Player ignores these values and
                                // extracts the channel and sample rate data
                                // encoded in the AAC bit stream
                                mySoundRate = 44100;
                                mySoundSize = 16;
                                mySoundType = true;
                            }
                            else if (myAudioCodecId == AudioCodec.SPEEX.getId())
                            {
                                LOGGER.trace("Speex audio type");
                                mySoundRate = 5500; // actually 16kHz
                                mySoundSize = 16;
                                mySoundType = false; // mono
                            }
                            else
                            {
                                switch ((id & ITag.MASK_SOUND_RATE) >> 2)
                                {
                                    case ITag.FLAG_RATE_5_5_KHZ:
                                        mySoundRate = 5500;
                                        break;
                                    case ITag.FLAG_RATE_11_KHZ:
                                        mySoundRate = 11000;
                                        break;
                                    case ITag.FLAG_RATE_22_KHZ:
                                        mySoundRate = 22000;
                                        break;
                                    case ITag.FLAG_RATE_44_KHZ:
                                        mySoundRate = 44100;
                                        break;
                                }
                                LOGGER.debug("Sound rate: {}", mySoundRate);
                                switch ((id & ITag.MASK_SOUND_SIZE) >> 1)
                                {
                                    case ITag.FLAG_SIZE_8_BIT:
                                        mySoundSize = 8;
                                        break;
                                    case ITag.FLAG_SIZE_16_BIT:
                                        mySoundSize = 16;
                                        break;
                                }
                                LOGGER.debug("Sound size: {}", mySoundSize);
                                // mono == 0 // stereo == 1
                                mySoundType = (id & ITag.MASK_SOUND_TYPE) > 0;
                                LOGGER.debug("Sound type: {}", mySoundType);
                            }
                        }
                        // XXX is AACPacketType needed here?
                    }
                    else if (dataType == ITag.TYPE_VIDEO)
                    {
                        myVideoDataSize += bodySize;
                        if (myVideoCodecId == -1)
                        {
                            int id = bodyBuf[0] & 0xff; // must be unsigned
                            myVideoCodecId = id & ITag.MASK_VIDEO_CODEC;
                            LOGGER.debug("Video codec id: {}", myVideoCodecId);
                        }
                    }
                }
                // Data Type
                IOUtils.writeUnsignedByte(tagBuffer, dataType); // 1
                // Body Size - Length of the message. Number of bytes after
                // StreamID to end of tag
                // (Equal to length of the tag - 11)
                IOUtils.writeMediumInt(tagBuffer, bodySize); // 3
                // Timestamp
                IOUtils.writeExtendedMediumInt(tagBuffer, timestamp); // 4
                // Stream id
                tagBuffer.put(DEFAULT_STREAM_ID); // 3
                LOGGER.trace("Tag buffer (after tag header) limit: {} remaining: {}", tagBuffer.limit(), tagBuffer.remaining());
                // get the body if we have one
                if (bodyBuf != null)
                {
                    tagBuffer.put(bodyBuf);
                    LOGGER.trace("Tag buffer (after body) limit: {} remaining: {}", tagBuffer.limit(), tagBuffer.remaining());
                }
                // we add the tag size
                tagBuffer.putInt(TAG_HEADER_LENGTH + bodySize);
                LOGGER.trace("Tag buffer (after prev tag size) limit: {} remaining: {}", tagBuffer.limit(), tagBuffer.remaining());
                // flip so we can process from the beginning
                tagBuffer.flip();
                if (LOGGER.isDebugEnabled())
                {
                    // StringBuilder sb = new StringBuilder();
                    // HexDump.dumpHex(sb, tagBuffer.array());
                    // log.debug("\n{}", sb);
                }
                // write the tag
                myDataFile.write(tagBuffer.array());
                myBytesWritten = myDataFile.length();
                LOGGER.trace("Tag written, check value: {} (should be 0)", myBytesWritten - prevBytesWritten - totalTagSize);
                tagBuffer.clear();
                // update the duration
                myDuration = Math.max(myDuration, timestamp);
                LOGGER.debug("Writer duration: {}", myDuration);
                // validate written amount
                if (myBytesWritten - prevBytesWritten != totalTagSize)
                {
                    LOGGER.debug("Not all of the bytes appear to have been written, prev-current: {}",
                            myBytesWritten - prevBytesWritten);
                }
                return true;
            }
            else
            {
                // throw an exception and let them know the cause
                throw new IOException("FLV write channel has been closed", new ClosedChannelException());
            }
        }
        catch (InterruptedException e)
        {
            LOGGER.warn("Exception acquiring lock", e);
        }
        finally
        {
            myLock.release();
        }
        return false;
    }

    @Override
    public boolean writeTag(byte type, IoBuffer data) throws IOException
    {
        return false;
    }

    @Override
    public boolean writeStream(byte[] b)
    {
        try
        {
            myDataFile.write(b);
            return true;
        }
        catch (IOException e)
        {
            LOGGER.error("", e);
        }
        return false;
    }

    /**
     * Write "onMetaData" tag to the file.
     *
     * @param duration Duration to write in milliseconds.
     * @param videoCodecId Id of the video codec used while recording.
     * @param audioCodecId Id of the audio codec used while recording.
     * @throws IOException if the tag could not be written
     */
    private void writeMetadataTag(double duration, int videoCodecId, int audioCodecId) throws IOException
    {
        LOGGER.debug("writeMetadataTag - duration: {} video codec: {} audio codec: {}", new Object[] { duration, videoCodecId,
            audioCodecId });
        IoBuffer buf = IoBuffer.allocate(1024);
        buf.setAutoExpand(true);
        Output out = new Output(buf);
        out.writeString("onMetaData");
        Map<Object, Object> params = new HashMap<Object, Object>();
        params.put("server", "Red5");
        params.put("creationdate", GregorianCalendar.getInstance().getTime().toString());
        params.put("duration", duration);
        if (videoCodecId != -1)
        {
            params.put("videocodecid", videoCodecId);
            params.put("videodatarate", 8 * myVideoDataSize / 1024 / duration); // from
                                                                              // bytes
                                                                              // to
                                                                              // kilobits
        }
        else
        {
            // place holder
            params.put("novideocodec", 0);
        }
        if (audioCodecId != -1)
        {
            params.put("audiocodecid", audioCodecId);
            if (audioCodecId == AudioCodec.AAC.getId())
            {
                params.put("audiosamplerate", 44100);
                params.put("audiosamplesize", 16);
            }
            else if (audioCodecId == AudioCodec.SPEEX.getId())
            {
                params.put("audiosamplerate", 16000);
                params.put("audiosamplesize", 16);
            }
            else
            {
                params.put("audiosamplerate", mySoundRate);
                params.put("audiosamplesize", mySoundSize);
            }
            params.put("stereo", mySoundType);
            params.put("audiodatarate", 8 * myAudioDataSize / 1024 / duration); // from
                                                                              // bytes
                                                                              // to
                                                                              // kilobits
        }
        else
        {
            // place holder
            params.put("noaudiocodec", 0);
        }
        // this is actual only supposed to be true if the last video frame is a
        // keyframe
        params.put("canSeekToEnd", true);
        out.writeMap(params);
        buf.flip();
        int bodySize = buf.limit();
        LOGGER.debug("Metadata size: {}", bodySize);
        // set a var holding the entire tag size including the previous tag
        // length
        int totalTagSize = TAG_HEADER_LENGTH + bodySize + 4;
        // resize
        myFile.setLength(myFile.length() + totalTagSize);
        // create a buffer for this tag
        ByteBuffer tagBuffer = ByteBuffer.allocate(totalTagSize);
        // get the timestamp
        int timestamp = 0;
        // create an array big enough
        byte[] bodyBuf = new byte[bodySize];
        // put the bytes into the array
        buf.get(bodyBuf);
        // Data Type
        IOUtils.writeUnsignedByte(tagBuffer, ITag.TYPE_METADATA); // 1
        // Body Size - Length of the message. Number of bytes after StreamID to
        // end of tag
        // (Equal to length of the tag - 11)
        IOUtils.writeMediumInt(tagBuffer, bodySize); // 3
        // Timestamp
        IOUtils.writeExtendedMediumInt(tagBuffer, timestamp); // 4
        // Stream id
        tagBuffer.put(DEFAULT_STREAM_ID); // 3
        LOGGER.trace("Tag buffer (after tag header) limit: {} remaining: {}", tagBuffer.limit(), tagBuffer.remaining());
        // get the body
        tagBuffer.put(bodyBuf);
        LOGGER.trace("Tag buffer (after body) limit: {} remaining: {}", tagBuffer.limit(), tagBuffer.remaining());
        // we add the tag size
        tagBuffer.putInt(TAG_HEADER_LENGTH + bodySize);
        LOGGER.trace("Tag buffer (after prev tag size) limit: {} remaining: {}", tagBuffer.limit(), tagBuffer.remaining());
        // flip so we can process from the beginning
        tagBuffer.flip();
        // write the tag
        myFile.write(tagBuffer.array());
        myBytesWritten = myFile.length();
        tagBuffer.clear();
        buf.clear();
    }

    /**
     * Finalizes the FLV file.
     *
     * @return bytes transferred
     */
    private long finalizeFlv()
    {
        LOGGER.debug("Finalizing {}", myFilePath);
        long bytesTransferred = 0L;
        try
        {
            if (!myAppend)
            {
                // write the file header
                writeHeader();
                // write the metadata with the final duration
                writeMetadataTag(myDuration * 0.001d, myVideoCodecId, myAudioCodecId);
                // ensure we have the data file (*.ser)
                if (myDataFile == null)
                {
                    myDataFile = new RandomAccessFile(myFilePath + ".ser", "r");
                }
                // set the data file the beginning
                myDataFile.seek(0);
                // transfer / write data file into final flv
                bytesTransferred = myFile.getChannel().transferFrom(myDataFile.getChannel(), myBytesWritten, myDataFile.length());
            }
            else
            {
                // TODO update duration
                LOGGER.warn("Adjustment of duration on append is not supported at this time");
            }
            // close and remove the ser file if write was successful
            if (myDataFile != null && bytesTransferred > 0)
            {
                // close the file
                myDataFile.close();
                myDataFile = null;
                // delete the data file only if the bytes were transferred to
                // the flv destination
                if (bytesTransferred > 0)
                {
                    File dat = new File(myFilePath + ".ser");
                    if (dat.exists())
                    {
                        dat.delete();
                    }
                }
                else
                {
                    LOGGER.warn("FLV serial file not deleted due to transfer error");
                }
            }
        }
        catch (Exception e)
        {
            LOGGER.warn("Finalization of flv file failed; new finalize job will be spawned", e);
        }
        finally
        {
            if (myFile != null)
            {
                // close the file
                try
                {
                    myFile.close();
                }
                catch (Exception e)
                {
                }
            }
        }
        return bytesTransferred;
    }

    /**
     * Ends the writing process, then merges the data file with the flv file
     * header and metadata.
     */
    public void close()
    {
        LOGGER.debug("close");
        // spawn a thread to finish up our flv writer work
        LOGGER.debug("Meta tags: {}", myMetaTags);
        long bytesTransferred = 0L;
        try
        {
            // wait 2s for a lock
            myLock.acquire(2000);
            bytesTransferred = finalizeFlv();
        }
        catch (InterruptedException e)
        {
            LOGGER.warn("Exception acquiring lock", e);
        }
        finally
        {
            myLock.release();
            LOGGER.debug("{} closed", myFilePath);
            // if write failed, spawn a job to finish up
            if (bytesTransferred == 0L)
            {
                // spawn job to write the finalized FLV file based on the ser
                // file
                new Thread(new FLVFinalizer(), "FLVFinalizer#" + System.currentTimeMillis()).start();
            }
        }
    }

    @Override
    public IStreamableFile getFile()
    {
        return myFLV;
    }

    /**
     * Setter for FLV object
     *
     * @param flv FLV source
     *
     */
    public void setFLV(IFLV flv)
    {
        myFLV = flv;
    }

    @Override
    public int getOffset()
    {
        return myPositionOffset;
    }

    /**
     * Setter for offset
     *
     * @param offset Value to set for offset
     */
    public void setOffset(int offset)
    {
        myPositionOffset = offset;
    }

    @Override
    public long getBytesWritten()
    {
        return myBytesWritten;
    }

    private final class FLVFinalizer implements Runnable
    {
        public void run()
        {
            LOGGER.debug("Finalizer run");
            try
            {
                // clear incomplete files ref
                myFile = null;
                // create an instance of the incomplete file
                File tmp = new File(myFilePath);
                // delete the file
                boolean deleted = tmp.delete();
                LOGGER.info("Deleted ({}) incomplete file: {}", deleted, myFilePath);
                // clear ref
                tmp = null;
                // quick sleep, cheap delay
                Thread.sleep(2000L);
            }
            catch (Exception e)
            {
                LOGGER.error("Error on cleanup of flv", e);
            }
            // attempt to finalize the flv
            finalizeFlv();
            LOGGER.debug("Finalizer exit");
        }
    }
}
