/* RED5 Open Source Flash Server - http://code.google.com/p/red5/
 *
 * Copyright 2006-2013 by respective authors (see below). All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License. */

package org.red5.io.amf;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.Vector;

import org.apache.commons.beanutils.BeanMap;
import org.apache.mina.core.buffer.IoBuffer;
import org.red5.annotations.Anonymous;
import org.red5.io.amf3.ByteArray;
import org.red5.io.object.BaseOutput;
import org.red5.io.object.RecordSet;
import org.red5.io.object.Serializer;
import org.red5.io.utils.XMLUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

/**
 * @author The Red5 Project
 * @author Luke Hubbard, Codegent Ltd (luke@codegent.com)
 * @author Paul Gregoire (mondain@gmail.com)
 * @author Harald Radi (harald.radi@nme.at)
 */
public class Output extends BaseOutput implements org.red5.io.object.Output
{
    protected static Logger log = LoggerFactory.getLogger(Output.class);

    /**
     * Output buffer
     */
    protected IoBuffer buf;

    /**
     * Creates output with given byte buffer
     *
     * @param buf Byte buffer
     */
    public Output(IoBuffer buf)
    {
        super();
        this.buf = buf;
    }

    @Override
    public boolean isCustom(Object custom)
    {
        return false;
    }

    protected boolean checkWriteReference(Object obj)
    {
        if (hasReference(obj))
        {
            writeReference(obj);
            return true;
        }
        else
        {
            return false;
        }
    }

    @Override
    public void writeArray(Collection<?> array)
    {
        if (checkWriteReference(array))
        {
            return;
        }
        storeReference(array);
        buf.put(AMF.TYPE_ARRAY);
        buf.putInt(array.size());
        for (Object item : array)
        {
            Serializer.serialize(this, item);
        }
    }

    @Override
    public void writeArray(Object[] array)
    {
        log.debug("writeArray - array: {}", array);
        if (array != null)
        {
            if (checkWriteReference(array))
            {
                return;
            }
            storeReference(array);
            buf.put(AMF.TYPE_ARRAY);
            buf.putInt(array.length);
            for (Object item : array)
            {
                Serializer.serialize(this, item);
            }
        }
        else
        {
            writeNull();
        }
    }

    @Override
    public void writeArray(Object array)
    {
        if (array != null)
        {
            if (checkWriteReference(array))
            {
                return;
            }
            storeReference(array);
            buf.put(AMF.TYPE_ARRAY);
            buf.putInt(Array.getLength(array));
            for (int i = 0; i < Array.getLength(array); i++)
            {
                Serializer.serialize(this, Array.get(array, i));
            }
        }
        else
        {
            writeNull();
        }
    }

    @Override
    public void writeMap(Map<Object, Object> map)
    {
        if (checkWriteReference(map))
        {
            return;
        }
        storeReference(map);
        buf.put(AMF.TYPE_MIXED_ARRAY);
        int maxInt = -1;
        for (int i = 0; i < map.size(); i++)
        {
            try
            {
                if (!map.containsKey(i))
                {
                    break;
                }
            }
            catch (ClassCastException err)
            {
                // Map has non-number keys
                break;
            }
            maxInt = i;
        }
        buf.putInt(maxInt + 1);
        // TODO: Need to support an incoming key named length
        for (Map.Entry<Object, Object> entry : map.entrySet())
        {
            final String key = entry.getKey().toString();
            if ("length".equals(key))
            {
                continue;
            }
            putString(key);
            Serializer.serialize(this, entry.getValue());
        }
        if (maxInt >= 0)
        {
            putString("length");
            Serializer.serialize(this, maxInt + 1);
        }
        buf.put((byte)0x00);
        buf.put((byte)0x00);
        buf.put(AMF.TYPE_END_OF_OBJECT);
    }

    @Override
    public void writeMap(Collection<?> array)
    {
        if (checkWriteReference(array))
        {
            return;
        }
        storeReference(array);
        buf.put(AMF.TYPE_MIXED_ARRAY);
        buf.putInt(array.size() + 1);
        int idx = 0;
        for (Object item : array)
        {
            if (item != null)
            {
                putString(String.valueOf(idx++));
                Serializer.serialize(this, item);
            }
            else
            {
                idx++;
            }
        }
        putString("length");
        Serializer.serialize(this, array.size() + 1);
        buf.put((byte)0x00);
        buf.put((byte)0x00);
        buf.put(AMF.TYPE_END_OF_OBJECT);
    }

    @Override
    public void writeRecordSet(RecordSet recordset)
    {
        if (checkWriteReference(recordset))
        {
            return;
        }
        storeReference(recordset);
        // Write out start of object marker
        buf.put(AMF.TYPE_CLASS_OBJECT);
        putString("RecordSet");
        // Serialize
        Map<String, Object> info = recordset.serialize();
        // Write out serverInfo key
        putString("serverInfo");
        // Serialize
        Serializer.serialize(this, info);
        // Write out end of object marker
        buf.put((byte)0x00);
        buf.put((byte)0x00);
        buf.put(AMF.TYPE_END_OF_OBJECT);
    }

    @Override
    public boolean supportsDataType(byte type)
    {
        return false;
    }

    @Override
    public void writeBoolean(Boolean bol)
    {
        buf.put(AMF.TYPE_BOOLEAN);
        buf.put(bol ? AMF.VALUE_TRUE : AMF.VALUE_FALSE);
    }

    @Override
    public void writeCustom(Object custom)
    {
    }

    @Override
    public void writeDate(Date date)
    {
        buf.put(AMF.TYPE_DATE);
        buf.putDouble(date.getTime());
        buf.putShort((short)(TimeZone.getDefault().getRawOffset() / 60 / 1000));
    }

    @Override
    public void writeNull()
    {
        // System.err.println("Write null");
        buf.put(AMF.TYPE_NULL);
    }

    @Override
    public void writeNumber(Number num)
    {
        buf.put(AMF.TYPE_NUMBER);
        buf.putDouble(num.doubleValue());
    }

    @Override
    public void writeReference(Object obj)
    {
        log.debug("Write reference");
        buf.put(AMF.TYPE_REFERENCE);
        buf.putShort(getReferenceId(obj));
    }

    @Override
    public void writeObject(Object object)
    {
    }

    protected boolean serializeField(Class<?> objectClass, String keyName, Field field, Method getter)
    {
        Map<String, Boolean> serializeMap = new HashMap<String, Boolean>();
        boolean serialize = Serializer.serializeField(keyName, field, getter);
        serializeMap.put(keyName, serialize);
        return serialize;
    }

    protected Field getField(Class<?> objectClass, String keyName)
    {
        // again, to prevent null pointers, check if the element exists first.
        Map<String, Field> fieldMap = new HashMap<String, Field>();
        Field field = null;
        if (fieldMap.containsKey(keyName))
        {
            field = fieldMap.get(keyName);
        }
        else
        {
            for (Class<?> clazz = objectClass; !clazz.equals(Object.class); clazz = clazz.getSuperclass())
            {
                Field[] fields = clazz.getDeclaredFields();
                if (fields.length > 0)
                {
                    for (Field fld : fields)
                    {
                        if (fld.getName().equals(keyName))
                        {
                            field = fld;
                            break;
                        }
                    }
                }
            }
            fieldMap.put(keyName, field);
        }
        return field;
    }

    @Override
    public void writeObject(Map<Object, Object> map)
    {
        if (checkWriteReference(map))
        {
            return;
        }
        storeReference(map);
        buf.put(AMF.TYPE_OBJECT);
        boolean isBeanMap = map instanceof BeanMap;
        for (Map.Entry<Object, Object> entry : map.entrySet())
        {
            if (isBeanMap && "class".equals(entry.getKey()))
            {
                continue;
            }
            putString(entry.getKey().toString());
            Serializer.serialize(this, entry.getValue());
        }
        buf.put((byte)0x00);
        buf.put((byte)0x00);
        buf.put(AMF.TYPE_END_OF_OBJECT);
    }

    /**
     * Writes an arbitrary object to the output.
     *
     * @param object Object to write
     */
    protected void writeArbitraryObject(Object object)
    {
        log.debug("writeObject");
        // If we need to serialize class information...
        Class<?> objectClass = object.getClass();
        if (!objectClass.isAnnotationPresent(Anonymous.class))
        {
            // Write out start object marker for class name
            buf.put(AMF.TYPE_CLASS_OBJECT);
            putString(buf, Serializer.getClassName(objectClass));
        }
        else
        {
            // Write out start object marker without class name
            buf.put(AMF.TYPE_OBJECT);
        }
        // Iterate thru fields of an object to build "name-value" map from it
        for (Field field : objectClass.getFields())
        {
            String fieldName = field.getName();
            log.debug("Field: {} class: {}", field, objectClass);
            // Check if the Field corresponding to the getter/setter pair is
            // transient
            if (!serializeField(objectClass, fieldName, field, null))
            {
                continue;
            }
            Object value;
            try
            {
                // Get field value
                value = field.get(object);
            }
            catch (IllegalAccessException err)
            {
                // Swallow on private and protected properties access exception
                continue;
            }
            // Write out prop name
            putString(buf, fieldName);
            // Write out
            Serializer.serialize(this, field, null, object, value);
        }
        // Write out end of object marker
        buf.put((byte)0x00);
        buf.put((byte)0x00);
        buf.put(AMF.TYPE_END_OF_OBJECT);
    }

    @Override
    public void writeString(String string)
    {
        final byte[] encoded = encodeString(string);
        final int len = encoded.length;
        if (len < AMF.LONG_STRING_LENGTH)
        {
            buf.put(AMF.TYPE_STRING);
            buf.putShort((short)len);
        }
        else
        {
            buf.put(AMF.TYPE_LONG_STRING);
            buf.putInt(len);
        }
        buf.put(encoded);
    }

    @Override
    public void writeByteArray(ByteArray array)
    {
        throw new RuntimeException("ByteArray objects not supported with AMF0");
    }

    @Override
    public void writeVectorInt(Vector<Integer> vector)
    {
        throw new RuntimeException("Vector objects not supported with AMF0");
    }

    @Override
    public void writeVectorUInt(Vector<Long> vector)
    {
        throw new RuntimeException("Vector objects not supported with AMF0");
    }

    @Override
    public void writeVectorNumber(Vector<Double> vector)
    {
        throw new RuntimeException("Vector objects not supported with AMF0");
    }

    @Override
    public void writeVectorObject(Vector<Object> vector)
    {
        throw new RuntimeException("Vector objects not supported with AMF0");
    }

    /**
     * Encode string.
     *
     * @param string
     * @return encoded string
     */
    protected static byte[] encodeString(String string)
    {
        ByteBuffer buf = AMF.CHARSET.encode(string);
        byte[] encoded = new byte[buf.limit()];
        buf.get(encoded);
        return encoded;
    }

    /**
     * Write out string
     *
     * @param buf Byte buffer to write to
     * @param string String to write
     */
    public static void putString(IoBuffer buf, String string)
    {
        final byte[] encoded = encodeString(string);
        buf.putShort((short)encoded.length);
        buf.put(encoded);
    }

    @Override
    public void putString(String string)
    {
        putString(buf, string);
    }

    @Override
    public void writeXML(Document xml)
    {
        buf.put(AMF.TYPE_XML);
        putString(XMLUtils.docToString(xml));
    }

    /**
     * Convenience method to allow XML text to be used, instead of requiring an
     * XML Document.
     *
     * @param xml xml to write
     */
    public void writeXML(String xml)
    {
        buf.put(AMF.TYPE_XML);
        putString(xml);
    }

    /**
     * Return buffer of this Output object
     *
     * @return Byte buffer of this Output object
     */
    public IoBuffer buf()
    {
        return buf;
    }

    public void reset()
    {
        clearReferences();
    }
}