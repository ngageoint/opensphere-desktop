/* RED5 Open Source Flash Server - http://code.google.com/p/red5/
 *
 * Copyright 2006-2013 by respective authors (see below). All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License. */

package org.red5.io.flv.impl;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import org.apache.mina.core.buffer.IoBuffer;
import org.red5.codec.AudioCodec;
import org.red5.io.IStreamableFile;
import org.red5.io.ITag;
import org.red5.io.ITagWriter;
import org.red5.io.amf.Output;
import org.red5.io.flv.FLVHeader;
import org.red5.io.utils.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A Writer is used to write the contents of a FLV file.
 *
 * @author Red Leader (standingby@gmail.com)
 * @author Red 5 (imgoingin@yahoo.com)
 */
public class FLVStreamWriter implements ITagWriter
{
    /** Class level logger. */
    private static Logger LOGGER = LoggerFactory.getLogger(FLVStreamWriter.class);

    /**
     * Length of the flv header in bytes
     */
    public final static int HEADER_LENGTH = 9;

    /**
     * Length of the flv tag in bytes
     */
    public final static int TAG_HEADER_LENGTH = 11;

    /**
     * Position of the meta data tag in our file.
     */
    public final static int META_POSITION = 13;

    /**
     * For now all recorded streams carry a stream id of 0.
     */
    public final static byte[] DEFAULT_STREAM_ID = new byte[] { (byte)(0 & 0xff), (byte)(0 & 0xff), (byte)(0 & 0xff) };

    /**
     * Position in file
     */
    private int myTimeOffset;

    /**
     * Id of the video codec used.
     */
    private volatile int myVideoCodecId = -1;

    /**
     * Id of the audio codec used.
     */
    private volatile int myAudioCodecId = -1;

    /**
     * Sampling rate
     */
    private volatile int mySoundRate;

    /**
     * Size of each audio sample
     */
    private volatile int mySoundSize;

    /**
     * Mono (0) or stereo (1) sound
     */
    private volatile boolean mySoundType;

    /**
     * Are we appending to an existing file?
     */
    private final boolean myAppend;

    /**
     * Duration of the file.
     */
    private int myDuration;

    /**
     * Size of video data
     */
    private int myVideoDataSize = 0;

    /**
     * Size of audio data
     */
    private int myAudioDataSize = 0;

    private final OutputStream myOutputStream;

    /**
     * Creates writer implementation with given file and last tag
     *
     * FLV.java uses this constructor so we have access to the file object
     *
     * @param file File output stream
     * @param append true if append to existing file
     */
    public FLVStreamWriter(OutputStream outstream, boolean append)
    {
        if (outstream == null)
        {
            throw new IllegalStateException("An output stream must be provided.");
        }
        myOutputStream = outstream;
        myAppend = append;
    }

    /**
     * Writes the header bytes
     *
     * @throws IOException Any I/O exception
     */
    public synchronized void writeHeader() throws IOException
    {
        if (myVideoCodecId == -1 && myAudioCodecId == -1)
        {
            throw new IllegalStateException("No codec for stream.");
        }

        FLVHeader flvHeader = new FLVHeader();
        flvHeader.setFlagAudio(myAudioCodecId != -1 ? true : false);
        flvHeader.setFlagVideo(myVideoCodecId != -1 ? true : false);

        /* TODO it would be more efficient to write directly to the stream, but
         * since this is only written once, this is probably not a big deal. */
        /* FLVHeader (9 bytes) + PreviousTagSize0 (4 bytes) */
        byte[] bytes = new byte[FLVWriter.HEADER_LENGTH + 4];
        ByteBuffer header = ByteBuffer.wrap(bytes);
        flvHeader.write(header);

        myOutputStream.write(bytes);
    }

    private byte[] myTagBytes;

    private ByteBuffer acquireTagBuffer(int bytes)
    {
        if (myTagBytes == null || myTagBytes.length < bytes)
        {
            myTagBytes = new byte[bytes];
        }
        return ByteBuffer.wrap(myTagBytes);
    }

    private byte[] myBodyBytes;

    private byte[] acquireBodyBuffer(int bytes)
    {
        if (myBodyBytes == null || myBodyBytes.length < bytes)
        {
            myBodyBytes = new byte[bytes];
        }
        return myBodyBytes;
    }

    @Override
    public synchronized boolean writeTag(ITag tag) throws IOException
    {
        /* Tag header = 11 bytes |-|---|----|---| */
        /* 0 = type 1-3 = data size */
        /* 4-7 = timestamp */
        /* 8-10 = stream id (always 0) */
        /* Tag data = variable bytes */
        /* Previous tag = 4 bytes (tag header size + tag data size) */
        if (LOGGER.isTraceEnabled())
        {
            LOGGER.trace("writeTag: {}", tag);
        }
        // skip tags with no data
        int bodySize = tag.getBodySize();
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Tag body size: {}", bodySize);
        }

        // get the data type
        byte dataType = tag.getDataType();
        /* TODO For now, only process video data. If we want to process sound we
         * will need to have at least one sound and video tag so that we can
         * correctly write the header. Also, we must ensure that all of the
         * metadata tags are written before the first audio or video tag. */
        if (dataType != ITag.TYPE_VIDEO)
        {
            return false;
        }
        // set a var holding the entire tag size including the previous
        // tag length
        int totalTagSize = TAG_HEADER_LENGTH + bodySize + 4;
        ByteBuffer tagBuffer = acquireTagBuffer(totalTagSize);
        // get the timestamp
        int timestamp = tag.getTimestamp() + myTimeOffset;
        // allow for empty tag bodies
        byte[] bodyBuf = null;
        if (bodySize > 0)
        {
            /* There is a possibility that the backing buffer for the body was
             * directly allocated, so copy it into a byte array. */
            bodyBuf = acquireBodyBuffer(bodySize);
            // put the bytes into the array
            tag.getBody().get(bodyBuf, 0, bodySize);
            // get the audio or video codec identifier
            /* TODO Currently this will never be audio, but Leave it here in
             * case we start to support that. */
            if (dataType == ITag.TYPE_AUDIO)
            {
                myAudioDataSize += bodySize;
                if (myAudioCodecId == -1)
                {
                    int id = bodyBuf[0] & 0xff; // must be unsigned
                    myAudioCodecId = (id & ITag.MASK_SOUND_FORMAT) >> 4;
                    if (LOGGER.isDebugEnabled())
                    {
                        LOGGER.debug("Audio codec id: {}", myAudioCodecId);
                    }
                    // if aac use defaults
                    if (myAudioCodecId == AudioCodec.AAC.getId())
                    {
                        if (LOGGER.isTraceEnabled())
                        {
                            LOGGER.trace("AAC audio type");
                        }
                        // Flash Player ignores these values and
                        // extracts the channel and sample rate data
                        // encoded in the AAC bit stream
                        mySoundRate = 44100;
                        mySoundSize = 16;
                        mySoundType = true;
                    }
                    else if (myAudioCodecId == AudioCodec.SPEEX.getId())
                    {
                        if (LOGGER.isTraceEnabled())
                        {
                            LOGGER.trace("Speex audio type");
                        }
                        mySoundRate = 5500; // actually 16kHz
                        mySoundSize = 16;
                        mySoundType = false; // mono
                    }
                    else
                    {
                        switch ((id & ITag.MASK_SOUND_RATE) >> 2)
                        {
                            case ITag.FLAG_RATE_5_5_KHZ:
                                mySoundRate = 5500;
                                break;
                            case ITag.FLAG_RATE_11_KHZ:
                                mySoundRate = 11000;
                                break;
                            case ITag.FLAG_RATE_22_KHZ:
                                mySoundRate = 22000;
                                break;
                            case ITag.FLAG_RATE_44_KHZ:
                                mySoundRate = 44100;
                                break;
                        }
                        if (LOGGER.isDebugEnabled())
                        {
                            LOGGER.debug("Sound rate: {}", mySoundRate);
                        }
                        switch ((id & ITag.MASK_SOUND_SIZE) >> 1)
                        {
                            case ITag.FLAG_SIZE_8_BIT:
                                mySoundSize = 8;
                                break;
                            case ITag.FLAG_SIZE_16_BIT:
                                mySoundSize = 16;
                                break;
                        }
                        if (LOGGER.isDebugEnabled())
                        {
                            LOGGER.debug("Sound size: {}", mySoundSize);
                        }
                        // mono == 0 // stereo == 1
                        mySoundType = (id & ITag.MASK_SOUND_TYPE) > 0;
                        if (LOGGER.isDebugEnabled())
                        {
                            LOGGER.debug("Sound type: {}", mySoundType);
                        }
                    }
                }
                // XXX is AACPacketType needed here?
            }
            else if (dataType == ITag.TYPE_VIDEO)
            {
                myVideoDataSize += bodySize;
                if (myVideoCodecId == -1)
                {
                    int id = bodyBuf[0] & 0xff; // must be unsigned
                    myVideoCodecId = id & ITag.MASK_VIDEO_CODEC;
                    if (LOGGER.isDebugEnabled())
                    {
                        LOGGER.debug("Video codec id: {}", myVideoCodecId);
                    }

                    /* This is the first packet we've written, so write the
                     * header and meta data packet as well. */
                    if (!myAppend)
                    {
                        // write the file header
                        writeHeader();
                        // write the metadata with the final duration
                        writeMetadataTag(myDuration * 0.001d, myVideoCodecId, myAudioCodecId);
                    }
                }
            }
        }
        // Data Type
        IOUtils.writeUnsignedByte(tagBuffer, dataType); // 1
        // Body Size - Length of the message. Number of bytes after
        // StreamID to end of tag
        // (Equal to length of the tag - 11)
        IOUtils.writeMediumInt(tagBuffer, bodySize); // 3
        // Timestamp
        IOUtils.writeExtendedMediumInt(tagBuffer, timestamp); // 4
        // Stream id
        tagBuffer.put(DEFAULT_STREAM_ID); // 3
        if (LOGGER.isTraceEnabled())
        {
            LOGGER.trace("Tag buffer (after tag header) limit: {} remaining: {}", tagBuffer.limit(), tagBuffer.remaining());
        }
        // get the body if we have one
        if (bodyBuf != null)
        {
            tagBuffer.put(bodyBuf, 0, bodySize);
            if (LOGGER.isTraceEnabled())
            {
                LOGGER.trace("Tag buffer (after body) limit: {} remaining: {}", tagBuffer.limit(), tagBuffer.remaining());
            }
        }
        // we add the tag size
        tagBuffer.putInt(TAG_HEADER_LENGTH + bodySize);
        if (LOGGER.isTraceEnabled())
        {
            LOGGER.trace("Tag buffer (after prev tag size) limit: {} remaining: {}", tagBuffer.limit(), tagBuffer.remaining());
        }
        // don't need to flip the buffer, write the array directly.
//        tagBuffer.flip();
        // write the tag
        myOutputStream.write(myTagBytes, 0, totalTagSize);
        tagBuffer.clear();
        // update the duration
        myDuration = Math.max(myDuration, timestamp);
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("Writer duration: {}", myDuration);
        }
        myOutputStream.flush();
        return true;
    }

    @Override
    public synchronized boolean writeTag(byte type, IoBuffer data) throws IOException
    {
        return false;
    }

    @Override
    public synchronized boolean writeStream(byte[] b)
    {
        try
        {
            myOutputStream.write(b);
            return true;
        }
        catch (IOException e)
        {
            LOGGER.error("Failed to write to stream", e);
        }
        return false;
    }

    /**
     * Write "onMetaData" tag to the file.
     *
     * @param duration Duration to write in milliseconds.
     * @param videoCodecId Id of the video codec used while recording.
     * @param audioCodecId Id of the audio codec used while recording.
     * @throws IOException if the tag could not be written
     */
    private synchronized void writeMetadataTag(double duration, int videoCodecId, int audioCodecId) throws IOException
    {
        LOGGER.debug("writeMetadataTag - duration: {} video codec: {} audio codec: {}", new Object[] { duration, videoCodecId,
            audioCodecId });
        IoBuffer buf = IoBuffer.allocate(1024);
        buf.setAutoExpand(true);
        Output out = new Output(buf);
        out.writeString("onMetaData");
        Map<Object, Object> params = new HashMap<Object, Object>();
        params.put("server", "Red5");
        params.put("creationdate", GregorianCalendar.getInstance().getTime().toString());
        params.put("duration", duration);
        if (videoCodecId != -1)
        {
            params.put("videocodecid", videoCodecId);
            /* from bytes to kilobits */
            params.put("videodatarate", 8 * myVideoDataSize / 1024 / duration);
        }
        else
        {
            // place holder
            params.put("novideocodec", 0);
        }
        if (audioCodecId != -1)
        {
            params.put("audiocodecid", audioCodecId);
            if (audioCodecId == AudioCodec.AAC.getId())
            {
                params.put("audiosamplerate", 44100);
                params.put("audiosamplesize", 16);
            }
            else if (audioCodecId == AudioCodec.SPEEX.getId())
            {
                params.put("audiosamplerate", 16000);
                params.put("audiosamplesize", 16);
            }
            else
            {
                params.put("audiosamplerate", mySoundRate);
                params.put("audiosamplesize", mySoundSize);
            }
            params.put("stereo", mySoundType);
            /* from bytes to kilobits */
            params.put("audiodatarate", 8 * myAudioDataSize / 1024 / duration);
        }
        else
        {
            // place holder
            params.put("noaudiocodec", 0);
        }
        // this is actual only supposed to be true if the last video frame is a
        // keyframe
        params.put("canSeekToEnd", true);
        out.writeMap(params);
        buf.flip();
        int bodySize = buf.limit();
        LOGGER.debug("Metadata size: {}", bodySize);
        // set a var holding the entire tag size including the previous tag
        // length
        int totalTagSize = TAG_HEADER_LENGTH + bodySize + 4;
        // create a buffer for this tag
        ByteBuffer tagBuffer = ByteBuffer.allocate(totalTagSize);
        // get the timestamp
        int timestamp = 0;
        // create an array big enough
        byte[] bodyBuf = new byte[bodySize];
        // put the bytes into the array
        buf.get(bodyBuf);
        // Data Type
        IOUtils.writeUnsignedByte(tagBuffer, ITag.TYPE_METADATA); // 1
        // Body Size - Length of the message. Number of bytes after StreamID to
        // end of tag
        // (Equal to length of the tag - 11)
        IOUtils.writeMediumInt(tagBuffer, bodySize); // 3
        // Timestamp
        IOUtils.writeExtendedMediumInt(tagBuffer, timestamp); // 4
        // Stream id
        tagBuffer.put(DEFAULT_STREAM_ID); // 3
        LOGGER.trace("Tag buffer (after tag header) limit: {} remaining: {}", tagBuffer.limit(), tagBuffer.remaining());
        // get the body
        tagBuffer.put(bodyBuf);
        LOGGER.trace("Tag buffer (after body) limit: {} remaining: {}", tagBuffer.limit(), tagBuffer.remaining());
        // we add the tag size
        tagBuffer.putInt(TAG_HEADER_LENGTH + bodySize);
        LOGGER.trace("Tag buffer (after prev tag size) limit: {} remaining: {}", tagBuffer.limit(), tagBuffer.remaining());
        // flip so we can process from the beginning
        tagBuffer.flip();
        // write the tag
        myOutputStream.write(tagBuffer.array());
        tagBuffer.clear();
        buf.clear();
    }

    /**
     * Ends the writing process, then merges the data file with the flv file
     * header and metadata.
     */
    public void close()
    {
        // TODO should the stream be closed by the provider or should this
        // implement closable and close the stream?
    }

    @Override
    public IStreamableFile getFile()
    {
        return null;
    }

    @Override
    public int getOffset()
    {
        return -1;
    }

    @Override
    public long getBytesWritten()
    {
        return -1;
    }
}
